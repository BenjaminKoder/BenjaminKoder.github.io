function menuToggle() {
    const toggleMenu = document.querySelector("#meny");
    toggleMenu.classList.toggle("active");
}